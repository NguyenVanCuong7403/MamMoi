import React from "react";
import { Input } from "@/components/ui/input";
import { useVnAdmin, normalize as vnNormalize } from "@/lib/useVnAdmin";

/* ===== helpers ===== */
const norm = (s) => vnNormalize(String(s || ""));
const labelOf = (x) =>
  typeof x === "string"
    ? x
    : (x?.full_name || x?.name || x?.label || x?.text || "");
const codeOf = (x) =>
  typeof x === "string" ? "" : String(x?.code || x?.value || x?.id || "");

const stripPrefixes = (s) =>
  s
    .replace(
      /\b(tinh|tỉnh|thanh pho|thành phố|tp|quan|quận|huyen|huyện|thi xa|thị xã|thi tran|thị trấn|xa|xã|phuong|phường)\b/g,
      ""
    )
    .replace(/\s+/g, " ")
    .trim();

const samePlace = (a, b) => {
  const A = norm(a),
    B = norm(b);
  if (!A || !B) return false;
  if (A === B) return true;
  const A2 = stripPrefixes(A),
    B2 = stripPrefixes(B);
  return A2 && B2 && A2 === B2;
};

function FieldLabel({ children, required }) {
  return (
    <div className="mb-1 text-sm text-neutral-600">
      {children}
      {required ? <span className="text-rose-600"> *</span> : null}
    </div>
  );
}

function SuggestList({ items = [], activeLabel = "", onPick }) {
  if (!items.length)
    return (
      <div className="absolute z-[1600] left-0 right-0 mt-1 rounded-xl border bg-white p-2 text-sm text-neutral-500 shadow">
        Không tìm thấy
      </div>
    );
  return (
    <div className="absolute z-[1600] left-0 right-0 mt-1 max-h-64 overflow-auto rounded-xl border bg-white p-1 shadow-xl">
      {items.map((it) => {
        const lbl = it.full_name || it.name;
        const active = lbl === activeLabel;
        return (
          <button
            type="button"
            key={String(it.code || lbl)}
            className={
              "w-full text-left rounded-lg px-3 py-2 text-sm hover:bg-neutral-50 " +
              (active ? "bg-emerald-50 text-emerald-700" : "text-neutral-800")
            }
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => onPick?.(it)}
            title={lbl}
          >
            {lbl}
          </button>
        );
      })}
    </div>
  );
}

/* ===== AddressPicker (chọn không cần theo thứ tự) ===== */
export default function AddressPicker({
  value = {}, // { province, district, ward, address } — object/string
  onChange,
  lockToSuggestion = true,
  required = true,
  inputClassOk = "h-11 w-full rounded-xl bg-white border border-neutral-300 placeholder:text-neutral-400 focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500",
  inputClassErr = "h-11 w-full rounded-xl bg-white border border-rose-500 placeholder:text-neutral-400 focus:ring-2 focus:ring-rose-500/40 focus:border-rose-500",
  placeholders = {
    province: "VD: Hà Nội",
    district: "VD: Cầu Giấy / Quốc Oai…",
    ward: "VD: Dịch Vọng",
    address: "Số nhà / Đường / Khu",
  },
  onBlurFields,
}) {
  const {
    loading,
    provinces,
    mapDistricts,
    mapWards,
    allDistricts,
    allWards,
    provinceWardsMap,
    districtToProvince,
    wardToDistrict,
  } = useVnAdmin();

  const [q, setQ] = React.useState({
    province: labelOf(value.province),
    district: labelOf(value.district),
    ward: labelOf(value.ward),
    address: value.address || "",
  });
  const [open, setOpen] = React.useState({
    province: false,
    district: false,
    ward: false,
  });
  const wrapRef = React.useRef(null);

  React.useEffect(() => {
    setQ({
      province: labelOf(value.province),
      district: labelOf(value.district),
      ward: labelOf(value.ward),
      address: value.address || "",
    });
  }, [value.province, value.district, value.ward, value.address]);

  // selection theo code trước, nếu không có dùng label
  const selectedProvince = React.useMemo(() => {
    const c = codeOf(value.province);
    if (c) return provinces.find((p) => String(p.code) === c) || null;
    const l = labelOf(value.province);
    return (
      provinces.find(
        (p) =>
          samePlace(p.full_name || p.name, l) || samePlace(p.name || "", l)
      ) || null
    );
  }, [provinces, value.province]);

  const selectedDistrict = React.useMemo(() => {
    const provCode = selectedProvince?.code;
    const source = provCode
      ? mapDistricts[String(provCode)] || []
      : allDistricts;
    const c = codeOf(value.district);
    if (c) return source.find((d) => String(d.code) === c) || null;
    const l = labelOf(value.district);
    return (
      source.find(
        (d) => samePlace(d.full_name || d.name, l) || samePlace(d.name || "", l)
      ) || null
    );
  }, [selectedProvince, mapDistricts, allDistricts, value.district]);

  // nguồn gợi ý quận/huyện (không cần theo thứ tự)
  const districtSource = React.useMemo(() => {
    if (selectedProvince) return mapDistricts[String(selectedProvince.code)] || [];
    return allDistricts;
  }, [selectedProvince, mapDistricts, allDistricts]);

  // nguồn gợi ý phường/xã (không cần theo thứ tự)
  const wardSource = React.useMemo(() => {
    if (selectedDistrict) return mapWards[String(selectedDistrict.code)] || [];
    if (selectedProvince) return provinceWardsMap[String(selectedProvince.code)] || [];
    return allWards;
  }, [selectedProvince, selectedDistrict, mapWards, provinceWardsMap, allWards]);

  // lọc gợi ý
  const filter = (list, keyword) => {
    const k = norm(keyword);
    if (!k) return list.slice(0, 20);
    return list
      .filter((it) => {
        const L = norm(it.full_name || it.name);
        return L.includes(k) || stripPrefixes(L).includes(k);
      })
      .slice(0, 20);
  };

  // revert nếu không khớp
  const forceValidOrRevert = (level) => {
    const list =
      level === "province" ? provinces : level === "district" ? districtSource : wardSource;
    const txt = q[level];
    const found = list.find(
      (it) =>
        samePlace(it.full_name || it.name, txt) ||
        samePlace(it.name || "", txt)
    );
    if (found) {
      if (
        (level === "province" && codeOf(value.province) !== String(found.code)) ||
        (level === "district" && codeOf(value.district) !== String(found.code)) ||
        (level === "ward" && codeOf(value.ward) !== String(found.code))
      ) {
        pick(level, found);
      }
    } else if (lockToSuggestion) {
      setQ((s) => ({ ...s, [level]: labelOf(value[level]) }));
    }
  };

  // pick item từ gợi ý, tự suy ra cấp trên nếu cần
  const pick = (level, item) => {
    const lbl = item.full_name || item.name || "";
    setOpen((o) => ({ ...o, [level]: false }));

    if (level === "province") {
      setQ((s) => ({ ...s, province: lbl, district: "", ward: "" }));
      onChange?.({ province: item, district: null, ward: null });
      return;
    }

    if (level === "district") {
      setQ((s) => ({ ...s, district: lbl, ward: "" }));
      // suy ra province nếu chưa có hoặc khác
      const pCode = districtToProvince[String(item.code)];
      if (pCode && (!selectedProvince || String(selectedProvince.code) !== pCode)) {
        const prov = provinces.find((p) => String(p.code) === pCode);
        if (prov) {
          setQ((s) => ({ ...s, province: prov.full_name || prov.name || "" }));
          onChange?.({ province: prov, district: item, ward: null });
          return;
        }
      }
      onChange?.({ district: item, ward: null });
      return;
    }

    // level === "ward"
    setQ((s) => ({ ...s, ward: lbl }));
    const dCode = wardToDistrict[String(item.code)];
    if (dCode) {
      const dist =
        (mapWards[String(dCode)] && (districtSource.find((d) => String(d.code) === dCode) || { code: dCode })) ||
        null;
      const provCode = districtToProvince[String(dCode)];
      const prov =
        (provCode && provinces.find((p) => String(p.code) === provCode)) || null;

      if (prov && (!selectedProvince || String(selectedProvince.code) !== prov.code)) {
        setQ((s) => ({ ...s, province: prov.full_name || prov.name || "" }));
      }
      if (dist && (!selectedDistrict || String(selectedDistrict.code) !== String(dist.code))) {
        const lblD = dist.full_name || dist.name || "";
        setQ((s) => ({ ...s, district: lblD }));
      }
      onChange?.({ province: prov || undefined, district: dist || undefined, ward: item });
    } else {
      onChange?.({ ward: item });
    }
  };

  const handleBlur = (level) => {
    setTimeout(() => {
      setOpen((o) => ({ ...o, [level]: false }));
      forceValidOrRevert(level);
      onBlurFields?.();
    }, 80);
  };

  React.useEffect(() => {
    const onDocClick = (e) => {
      if (!wrapRef.current) return;
      if (!wrapRef.current.contains(e.target)) {
        setOpen({ province: false, district: false, ward: false });
      }
    };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  return (
    <div ref={wrapRef} className="grid grid-cols-1 md:grid-cols-2 gap-3">
      {/* Province */}
      <div className="relative">
        <FieldLabel required={required}>Tỉnh / Thành phố</FieldLabel>
        <Input
          value={q.province}
          onChange={(e) => {
            setQ((s) => ({ ...s, province: e.target.value }));
            setOpen((o) => ({ ...o, province: true }));
          }}
          onFocus={() => setOpen((o) => ({ ...o, province: true }))}
          onBlur={() => handleBlur("province")}
          placeholder={placeholders.province}
          autoComplete="off"
          spellCheck={false}
          className={inputClassOk}
        />
        {open.province && !loading && (
          <SuggestList
            items={filter(provinces, q.province)}
            activeLabel={labelOf(value.province)}
            onPick={(it) => pick("province", it)}
          />
        )}
      </div>

      {/* District (không khoá theo tỉnh; nếu đã có tỉnh → chỉ hiển thị huyện của tỉnh đó) */}
      <div className="relative">
        <FieldLabel required={required}>Quận / Huyện</FieldLabel>
        <Input
          value={q.district}
          onChange={(e) => {
            setQ((s) => ({ ...s, district: e.target.value }));
            setOpen((o) => ({ ...o, district: true }));
          }}
          onFocus={() => setOpen((o) => ({ ...o, district: true }))}
          onBlur={() => handleBlur("district")}
          placeholder={placeholders.district}
          autoComplete="off"
          spellCheck={false}
          className={inputClassOk}
        />
        {open.district && !loading && (
          <SuggestList
            items={filter(districtSource, q.district)}
            activeLabel={labelOf(value.district)}
            onPick={(it) => pick("district", it)}
          />
        )}
      </div>

      {/* Ward (không khoá theo quận; nếu đã có tỉnh → gợi ý toàn bộ phường của tỉnh; nếu có quận → chỉ phường trong quận) */}
      <div className="relative">
        <FieldLabel required={required}>Phường / Xã</FieldLabel>
        <Input
          value={q.ward}
          onChange={(e) => {
            setQ((s) => ({ ...s, ward: e.target.value }));
            setOpen((o) => ({ ...o, ward: true }));
          }}
          onFocus={() => setOpen((o) => ({ ...o, ward: true }))}
          onBlur={() => handleBlur("ward")}
          placeholder={placeholders.ward}
          autoComplete="off"
          spellCheck={false}
          className={inputClassOk}
        />
        {open.ward && !loading && (
          <SuggestList
            items={filter(wardSource, q.ward)}
            activeLabel={labelOf(value.ward)}
            onPick={(it) => pick("ward", it)}
          />
        )}
      </div>

      {/* Address detail */}
      <div>
        <FieldLabel required={required}>Địa chỉ chi tiết</FieldLabel>
        <Input
          value={q.address}
          onChange={(e) => {
            const v = e.target.value;
            setQ((s) => ({ ...s, address: v }));
            onChange?.({ address: v });
          }}
          onBlur={() => onBlurFields?.()}
          placeholder={placeholders.address}
          className={inputClassOk}
        />
      </div>
    </div>
  );
}
