import React, { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  TreePine,
  Hash,
  Calendar,
  Sprout,
  Info,
  Flower2,
  Apple,
  Branch,
  BadgeCheck,
  Leaf,
  Image as ImageIcon,
} from "lucide-react";

/* ===== helpers ===== */
const monthsBetween = (isoOrStr) => {
  if (!isoOrStr) return 0;
  const d = new Date(isoOrStr);
  if (isNaN(d)) return 0;
  const now = new Date();
  let m = (now.getFullYear() - d.getFullYear()) * 12 + (now.getMonth() - d.getMonth());
  if (now.getDate() < d.getDate()) m -= 1;
  return Math.max(0, m);
};

const formatVN = (d) => {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt)) return String(d);
  const dd = String(dt.getDate()).padStart(2, "0");
  const mm = String(dt.getMonth() + 1).padStart(2, "0");
  const yy = dt.getFullYear();
  return `${dd}/${mm}/${yy}`;
};

// Nếu field mở để nhập mà người dùng không điền -> "Bình thường" (không được "---")
const safeOpen = (v) => {
  const s = String(v ?? "").trim();
  return s ? s : "Bình thường";
};

const Row = ({ label, value, icon: Icon }) => (
  <div className="flex items-start gap-3">
    <div className="mt-1 text-emerald-700">
      {Icon ? <Icon className="w-4 h-4" /> : null}
    </div>
    <div>
      <div className="text-sm text-muted-foreground">{label}</div>
      <div className="text-lg md:text-xl font-medium leading-7">{value || "—"}</div>
    </div>
  </div>
);

const SectionHeader = ({ icon: Icon, title, right }) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center gap-3">
      <div className="h-10 w-10 rounded-xl bg-emerald-600/10 text-emerald-700 grid place-items-center">
        <Icon className="w-5 h-5" />
      </div>
      <div className="text-xl md:text-2xl font-bold tracking-tight">{title}</div>
    </div>
    {right}
  </div>
);

export default function TreeInfoPanel({
  tree = {},
  phen = {},
  canEditFlower = false,
  canEditFruit = false,
  statusChip = "Đang chăm sóc",
  onUpdateClick,
  renderImageBox, // truyền uploader/thumbnail cũ qua slot này
}) {
  const {
    typeName,      // "Xoài"
    code,          // "#T-001"
    variety,       // "Cát chu"
    plantDate,     // "2023-04-15" (nên để yyyy-mm-dd)
    preAgeMonths,  // 5
    soilType,      // "Đất phù sa cao ráo"
  } = tree;

  // Tổng tuổi = tháng từ ngày trồng + tuổi trước khi trồng
  const totalAge = useMemo(() => {
    const grown = monthsBetween(plantDate);
    const pre = Number(preAgeMonths || 0);
    return grown + pre;
  }, [plantDate, preAgeMonths]);

  const leafVal   = safeOpen(phen.leaf ?? phen.la);
  const branchVal = safeOpen(phen.branch ?? phen.canh);
  const flowerVal = canEditFlower ? safeOpen(phen.flower) : "Chưa đến giai đoạn";
  const fruitVal  = canEditFruit  ? safeOpen(phen.fruit)  : "Chưa đến giai đoạn";

  return (
    <div className="space-y-5">
      {/* Thông tin cây */}
      <Card className="border-0 shadow-sm ring-1 ring-black/5 overflow-hidden">
        <div className="px-5 pt-4 pb-3 border-b bg-gradient-to-r from-emerald-50 to-transparent">
          <SectionHeader
            icon={TreePine}
            title="Thông tin cây"
            right={
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center gap-1 rounded-full border px-3 py-1 text-sm bg-white shadow-sm">
                  <BadgeCheck className="w-4 h-4" />
                  {statusChip}
                </span>
                <Button onClick={onUpdateClick}>Cập nhật</Button>
              </div>
            }
          />
        </div>

        <CardContent className="p-5">
          <div className="grid md:grid-cols-3 gap-6">
            {/* trái: thông tin */}
            <div className="md:col-span-2 grid sm:grid-cols-2 gap-6">
              <Row label="Cây" value={typeName} icon={TreePine} />
              <Row label="Mã cây" value={code} icon={Hash} />
              <Row label="Giống/Variety" value={variety} icon={Sprout} />
              <Row label="Ngày trồng" value={formatVN(plantDate)} icon={Calendar} />
              <Row label="Loại đất" value={soilType} icon={Info} />
              <Row label="Tuổi trước khi trồng" value={`${Number(preAgeMonths || 0)} tháng`} icon={Info} />
              <Row label="Tổng tuổi" value={`${totalAge} tháng`} icon={BadgeCheck} />
            </div>

            {/* phải: ảnh/uploader */}
            <div className="md:col-span-1">
              <div className="text-sm text-muted-foreground mb-2 flex items-center gap-2">
                <ImageIcon className="w-4 h-4" /> Ảnh cây
              </div>
              <div className="rounded-xl border bg-white/70 p-2 min-h-[220px] grid">
                {typeof renderImageBox === "function" ? (
                  renderImageBox()
                ) : (
                  <div className="text-center text-sm text-muted-foreground grid place-items-center">
                    (truyền uploader cũ qua prop <code>renderImageBox</code>)
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tình trạng hiện tại */}
      <Card className="border-0 shadow-sm ring-1 ring-black/5 overflow-hidden">
        <div className="px-5 pt-4 pb-3 border-b bg-gradient-to-r from-emerald-50 to-transparent">
          <SectionHeader icon={Info} title="Tình trạng hiện tại" />
        </div>
        <CardContent className="p-5">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Row label="Lá" value={leafVal} icon={Leaf} />
            <Row label="Cành" value={branchVal} icon={Branch} />
            <Row label="Hoa" value={flowerVal} icon={Flower2} />
            <Row label="Quả" value={fruitVal} icon={Apple} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
